# Chess Championship – play online with anyone, anywhere

This folder is ONE small app: `server.js` serves the game (`index.html`) AND connects the two players.
Because moves go through the server over normal web traffic, it works between any two networks
(different states, countries, mobile data, office Wi-Fi) with no firewall or router problems.

## Deploy once (free) on Render – about 10 minutes
1. Create a free account at https://github.com, click **New repository** (name: `chess-online`), then
   **uploading an existing file** and upload the 3 files: `server.js`, `package.json`, `index.html`. Click **Commit**.
2. Create a free account at https://render.com → **New +** → **Web Service** → connect your GitHub
   → pick `chess-online`.
3. Settings: **Runtime: Node** · **Build Command:** leave empty (or `npm install`) · **Start Command:** `node server.js`
   · **Instance type: Free** → **Create Web Service**.
4. Wait for "Live". Your game address is shown at the top, e.g. `https://chess-online-xxxx.onrender.com`.

Send that same address to every player. One player taps **Competition → Create**, shares the 6-character code,
the other taps **Competition → Join** and types it. Both press **Start**.

## Good to know
* **Free plan sleeps** after ~15 minutes with no visitors; the first open then takes 30–60 seconds.
  To avoid that, add the address `https://YOUR-ADDRESS/__chess` to a free monitor such as UptimeRobot
  (check every 5 minutes), or use a paid plan.
* Works on any host that runs Node 18+ (Railway, Koyeb, Fly.io, a VPS …): run `node server.js`
  (it reads the `PORT` setting automatically). No `npm install` is needed – there are no dependencies.
* Try it on your own computer: `node server.js`, then open http://localhost:3000
* If you want to keep `index.html` on another website (Netlify, GitHub Pages …), open `index.html` in a text editor,
  find the line `window.CHESS_RELAY="";` and put your server address between the quotes, e.g.
  `window.CHESS_RELAY="https://chess-online-xxxx.onrender.com";`
* Games are kept in the server's memory only; nothing is stored or needs an account.
