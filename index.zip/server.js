/* Chess Championship - online relay server (zero dependencies, Node 18+).
   Serves index.html AND relays Competition moves between players over WebSocket,
   so two people anywhere in the world can play (no peer-to-peer / firewall problems). */
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const GRACE=15000,STALE=35000,MAXROOMS=2000;
const rooms=new Map();                               // code -> {st:{key:presence}, conns:{key:client}, gone:{key:ts}, t:ts}
const clean=d=>{const o={};if(!d||typeof d!=='object')return o;
  if(d.role==='host'||d.role==='guest')o.role=d.role;if('ready' in d)o.ready=!!d.ready;if('q' in d)o.q=d.q?1:0;
  if(typeof d.mv==='string')o.mv=d.mv.slice(0,2000);return o};
const san=(s,n)=>String(s||'').toLowerCase().replace(/[^a-z0-9-]/g,'').slice(0,n);

/* ---------- tiny WebSocket implementation (RFC 6455: text frames, ping/pong, close) ---------- */
function frame(op,buf){const n=buf.length;let h;
  if(n<126)h=Buffer.from([0x80|op,n]);else if(n<65536){h=Buffer.alloc(4);h[0]=0x80|op;h[1]=126;h.writeUInt16BE(n,2)}
  else{h=Buffer.alloc(10);h[0]=0x80|op;h[1]=127;h.writeBigUInt64BE(BigInt(n),2)}return Buffer.concat([h,buf])}
class Client{
  constructor(sock){this.sock=sock;this.buf=Buffer.alloc(0);this.frag=null;this.alive=true;this.last=Date.now();this.onmsg=()=>{};this.onclose=()=>{};
    sock.on('data',d=>{this.buf=Buffer.concat([this.buf,d]);try{this.parse()}catch(e){this.close()}});
    sock.on('close',()=>this.end());sock.on('error',()=>this.end());sock.setNoDelay(true)}
  parse(){for(;;){const b=this.buf;if(b.length<2)return;const fin=!!(b[0]&0x80),op=b[0]&15,mk=!!(b[1]&0x80);let len=b[1]&127,off=2;
    if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);off=4}else if(len===127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));off=10}
    if(len>65536){this.close();return}if(!mk){this.close();return}
    if(b.length<off+4+len)return;const key=b.slice(off,off+4);const p=Buffer.from(b.slice(off+4,off+4+len));for(let i=0;i<len;i++)p[i]^=key[i&3];
    this.buf=b.slice(off+4+len);this.last=Date.now();
    if(op===8){this.close();return}if(op===9){this.raw(10,p);continue}if(op===10)continue;
    if(op===1||op===0){if(op===1)this.frag=[];if(!this.frag)continue;this.frag.push(p);if(fin){const t=Buffer.concat(this.frag).toString('utf8');this.frag=null;this.onmsg(t)}}}}
  raw(op,p){if(this.alive)try{this.sock.write(frame(op,p))}catch(e){}}
  send(o){this.raw(1,Buffer.from(typeof o==='string'?o:JSON.stringify(o)))}
  ping(){this.raw(9,Buffer.alloc(0))}
  close(){if(this.alive){try{this.raw(8,Buffer.alloc(0));this.sock.end()}catch(e){}}this.end()}
  end(){if(!this.alive)return;this.alive=false;try{this.sock.destroy()}catch(e){}this.onclose()}
}

/* ---------- rooms ---------- */
function bc(r){const m=JSON.stringify({t:'s',all:r.st});for(const k in r.conns)r.conns[k].send(m)}
function drop(code,r,key){delete r.st[key];delete r.gone[key];const c=r.conns[key];delete r.conns[key];if(c)c.close();bc(r)}
function onClient(c,q){
  const code=san(q.get('room'),24),key=san(q.get('id'),32),host=q.get('host')==='1',rc=q.get('rc')==='1';
  const err=e=>{c.send({t:'err',e});setTimeout(()=>c.close(),50)};
  if(!code||!key||(host&&key!=='h')||(!host&&key[0]!=='c'))return err('bad');
  let r=rooms.get(code);
  if(host){
    if(r&&!(rc&&key in r.st))return err('taken');
    if(!r){if(rooms.size>=MAXROOMS)return err('busy');r={st:{},conns:{},gone:{},t:Date.now()};rooms.set(code,r)}
  }else{
    if(!r)return err('notfound');
    if(!(key in r.st)&&Object.keys(r.st).filter(k=>k[0]==='c').length>=1)return err('full');
  }
  const old=r.conns[key];if(old&&old!==c){delete r.conns[key];old.close()}
  r.conns[key]=c;delete r.gone[key];if(!r.st[key])r.st[key]={};r.t=Date.now();
  c.onmsg=t=>{let m;try{m=JSON.parse(t)}catch(e){return}if(!m||r.conns[key]!==c)return;
    if(m.t==='p'){r.st[key]=Object.assign(r.st[key]||{},clean(m.d));bc(r)}
    else if(m.t==='h')c.send({t:'s',all:r.st});
    else if(m.t==='bye')drop(code,r,key)};
  c.onclose=()=>{if(r.conns[key]===c){delete r.conns[key];if(r.st[key])r.gone[key]=Date.now()}};
  bc(r);
}
setInterval(()=>{const now=Date.now();
  for(const [code,r] of rooms){let ch=false;
    for(const k in r.conns){const c=r.conns[k];if(now-c.last>STALE){delete r.conns[k];r.gone[k]=r.gone[k]||now;c.close()}else c.ping()}
    for(const k in r.gone)if(now-r.gone[k]>GRACE){delete r.gone[k];delete r.st[k];ch=true}
    if(ch)bc(r);
    if(!Object.keys(r.st).length&&now-r.t>5000)rooms.delete(code)}},2000);

/* ---------- http ---------- */
const server=http.createServer((req,res)=>{
  const u=new URL(req.url,'http://x');
  if(u.pathname==='/__chess'){res.writeHead(200,{'Content-Type':'text/plain','Access-Control-Allow-Origin':'*','Cache-Control':'no-store'});return res.end('chess-relay')}
  if(u.pathname==='/'||u.pathname==='/index.html'){fs.readFile(path.join(__dirname,'index.html'),(e,d)=>{
    if(e){res.writeHead(500);return res.end('index.html missing')}
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache'});res.end(d)});return}
  res.writeHead(404);res.end('Not found')});
server.on('upgrade',(req,sock)=>{
  const u=new URL(req.url,'http://x'),k=req.headers['sec-websocket-key'];
  if(u.pathname!=='/ws'||!k||String(req.headers.upgrade).toLowerCase()!=='websocket'){sock.destroy();return}
  const acc=crypto.createHash('sha1').update(k+GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+acc+'\r\n\r\n');
  onClient(new Client(sock),u.searchParams)});
server.listen(PORT,()=>console.log('Chess server running on port '+PORT));
